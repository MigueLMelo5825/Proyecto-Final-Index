<?php if (isset($mensaje)): ?>
    <p><?= htmlspecialchars($mensaje) ?></p>
<?php endif; ?>
