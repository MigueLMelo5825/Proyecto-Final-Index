<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Contraseña actualizada</title>
<link rel="stylesheet" href="web/css/forms.css">
<link rel="stylesheet" href="web/css/styleFuentes.css">
</head>

<body>
  <div class="container">
    <h1>Contraseña actualizada</h1>
    <br>
    <p>
      Tu contraseña se ha actualizado correctamente.  
      Ya puedes iniciar sesión con tu nueva contraseña.
    </p>

    <a href="index.php?ctl=login">
      <button type="button">Iniciar sesión</button>
    </a>

 
  </div>
</body>
</html>