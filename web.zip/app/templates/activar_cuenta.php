<?php include_once __DIR__ . '/header.php'; ?>

<div class="form-page">
  <div class="form-container">
    <h1>Cuenta activada</h1>
    <p>Tu cuenta ha sido activada correctamente.</p>

    <a href="index.php?ctl=login">
      <button type="button">Iniciar sesión</button>
    </a>
  </div>
</div>

<?php include_once __DIR__ . '/footer.php'; ?>
