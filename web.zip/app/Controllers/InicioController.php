<?php

class InicioController {
    public function inicio() {
        require __DIR__ . '/../templates/inicio.php';
    }
}
